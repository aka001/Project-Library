#!/usr/bin/env python
# -*- coding: utf-8 -*-
"PySimpleSOAP"
import client
import server
import simplexml
import transport